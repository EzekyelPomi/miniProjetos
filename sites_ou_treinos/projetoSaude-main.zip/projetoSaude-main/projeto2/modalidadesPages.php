!<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="style/index.css">
    </head>
    <title></title>
    <body>
        <header class="headerPrincipal">
            <div class="logo">
                <img src="/img/logo.jpg" alt="">
            </div>
            <nav>
                <ul>
                    <li><a href="">Sobre</a></li>
                    <li><a href="">Contato</a></li>
                </ul>
            </nav>
        </header>
        <div class="navegação">
            <nav>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="unidadesPage.php">Unidades</a></li>
                    <li><a href="">Modalidades</a></li>
                    <li><a href="">Contato</a></li>
                </ul>
            </nav>
        </div>
        <section>
            <div>
                <div>

                </div>
                <div>

                </div>
            </div>
            <div>
                <div>
                    
                </div>
                <div>

                </div>
            </div>
            <div>
                <div>
                    
                </div>
                <div>

                </div>
            </div>
            <div>
                <div>
                    
                </div>
                <div>

                </div>
            </div>
        </section>
        <footer>
            <div class="footerPrincipal">
                <span>
                    <img src="/img/logo.jpg" alt="">
                </span>
                <nav class="opcoesFooter">
                    <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="unidadesPage.php">Unidades</a></li>
                        <li><a href="">Modalidades</a></li>
                        <li><a href="">Contato</a></li>
                    </ul>
                </nav>
            </div>
            <div class="CR">
                © 2021 - Projeto@2 | Desenvolvido por Ezekyel Pomi
            </div>
        </footer>
    </body>
</html>