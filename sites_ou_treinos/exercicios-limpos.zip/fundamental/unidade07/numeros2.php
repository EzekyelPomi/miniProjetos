<?php
    $salario = 1095;
    $gasolina = 4.55;
?>

<!doctype html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Curso PHP FUNDAMENTAL</title>
    </head>

    <body>
        
        
        <?php
            // testar se é numérica


            // testar se é inteiro


            // testar se é float
        ?>
        
        
    </body>
</html>