<?php
    $_salada = array["Laranja","Uva","Abacate"];
?>

<!doctype html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Curso PHP FUNDAMENTAL</title>
    </head>

    <body>
        <?php 
            $_1telefone = "Matheus Fontenelle"; 
            echo $_1telefone;
        ?>
    </body>
</html>